export type SummaryData = {
    total: number;
    active: number;
    inactive: number;
};