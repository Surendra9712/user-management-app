export type PieChartData = {
    data: { name: string; value: number }[];
    title?: string;
    colors?: string[]
};