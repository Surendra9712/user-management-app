export enum GenderEnum {
    MALE=1,
    FEMALE=2,
    OTHER=3,
}