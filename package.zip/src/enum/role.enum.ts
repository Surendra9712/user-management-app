export enum RoleEnum {
    ADMIN="Admin",
    GENERAL_MANAGER="General Manager",
    BRANCH_MANAGER="Branch Manager",
    SALES_MANAGER="Sales Manager",
}