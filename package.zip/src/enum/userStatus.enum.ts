export enum UserStatusEnum {
    ACTIVE=1,
    INACTIVE=0
}